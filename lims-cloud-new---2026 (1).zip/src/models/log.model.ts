export interface Log {
  id: string;
  action: string;
  details: string;
  timestamp: any;
  user: string;
}
